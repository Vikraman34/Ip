window.addEventListener("load", create);

var level=0;
var hasFlippedCard = false;
var lockBoard = false;
var firstCard, secondCard;
var clicks=0;
var moves=0;
var score=0;
var i=0,j=0;
var size=6;

var cardname=["captain america","thor","black widow","ironman","batman","superman","spiderman","green lantern","flash","wonder woman"];
var source=["pictures/1.png","pictures/2.png","pictures/3.png","pictures/4.png","pictures/5.png","pictures/6.png","pictures/7.png","pictures/8.png","pictures/9.png","pictures/10.png"];

function create(){
  document.getElementById("moves").innerHTML="<b>Level "+(level+1)+"</b><br> No Moves ";
  document.getElementById("score").innerHTML="Score : "+score;

  let temp=document.createElement("section");
  temp.className="memory-game";
  temp.id="memory-game";
  document.body.appendChild(temp);

  var i=0;
  for(i=0;i<size;i++)
  {
    j=0;
    for(j=0;j<2;j++)
    {
      let temp1=document.createElement("div");
      temp1.className="memory-card"; 
      temp1.id=cardname[i];
      temp.appendChild(temp1);

      let temp2=document.createElement("img");
      temp2.className="front-face";
      temp2.id="front-face";
      temp2.src=source[i];
      temp1.appendChild(temp2);

      let temp3=document.createElement("img");
      temp3.className="back-face";
      temp3.id="back-face";
      temp3.src="pictures/0.png";
      temp1.appendChild(temp3);
    }
  }
  shuffle();
}

function shuffle(){
  var cards = document.querySelectorAll(".memory-card");

  for(i=0;i<cards.length;i++)
    cards[i].addEventListener("click", flipCard);

  cards.forEach(card => {
    var randomPos = Math.floor(Math.random() * cards.length);
    card.style.order = randomPos;
  });
  timer();
}

function flipCard() {
  if (lockBoard) 
    return;
  if (this == firstCard) 
    return;

  this.classList.add("flip");
  clicks+=1;
  moves=Math.floor(clicks/2);
  if(moves==1)
    document.getElementById("moves").innerHTML="<b>Level "+(level+1)+"</b><br>"+moves+" Move ";
  else if(moves>=2)
    document.getElementById("moves").innerHTML="<b>Level "+(level+1)+"</b><br>"+moves+" Moves ";

  if (!hasFlippedCard) {
    hasFlippedCard = true;
    firstCard = this;
    return;
  }

  secondCard = this;
  checkForMatch();
}

function checkForMatch() {
  var isMatch = false;
  if(firstCard.id == secondCard.id)
  {
    isMatch=true;
  }

  if(isMatch)
  {
    lockBoard=true;
    disableCards();
    score++;
    document.getElementById("score").innerHTML="Score : "+score;
    if(score==size)
      stop();
  }
  else
    unflipCards();
}

function disableCards() {
  firstCard.removeEventListener("click", flipCard);
  secondCard.removeEventListener("click", flipCard);
  setTimeout(invisible,1000);
}

function invisible(){
  firstCard.style.visibility="hidden";
  secondCard.style.visibility="hidden";
  firstCard.classList.remove("flip");
  secondCard.classList.remove("flip");
  resetBoard();
}

function unflipCards() {
  lockBoard = true;
  setTimeout(unflip, 1000);
}

function unflip(){
  firstCard.classList.remove("flip");
  secondCard.classList.remove("flip");
  resetBoard();
}

function resetBoard() {
  hasFlippedCard = false; 
  lockBoard = false;
  firstCard = null;
  secondCard = null;
}
   
var s=100;
function timer(){
  s--;
  if(s>0)
  {
    setTimeout(timer,1000);
    document.getElementById("timer").innerHTML= s+" s remaining";
  }
  else if(s==0)
  {
    document.getElementById("timer").innerHTML= s+" s remaining";
    lockBoard=true;
    setTimeout(function(){alert('timeout :(');},1000);
  }
}

function stop(){
  lockBoard=true;
  s=-1;
  if(level<2)
    setTimeout(function(){alert("You have won level "+(level+1)+" :) ...starting level "+(level+2));nextlevel();},1500);
  else
    setTimeout(function(){alert("You have won level "+(level+1)+" :) ...bye");},1500);
}

function visible(){
  cards = document.querySelectorAll(".memory-card");

  for(i=0;i<cards.length;i++)
    cards[i].style.visibility="visible";
}

function nextlevel(){
  level++;
  clicks=0;
  moves=0;
  score=0;
  document.getElementById("moves").innerHTML="<b>Level "+(level+1)+"</b><br> No Moves ";
  document.getElementById("score").innerHTML="Score : "+score;
  visible();

  let temp=document.getElementById("memory-game");
  for(i=size;i<size+2;i++)
  {
    j=0;
    for(j=0;j<2;j++)
    {
      let temp1=document.createElement("div");
      temp1.className="memory-card"; 
      temp1.id=cardname[i];
      temp.appendChild(temp1);

      let temp2=document.createElement("img");
      temp2.className="front-face";
      temp2.id="front-face";
      temp2.src=source[i];
      temp1.appendChild(temp2);

      let temp3=document.createElement("img");
      temp3.className="back-face";
      temp3.id="back-face";
      temp3.src="pictures/0.png";
      temp1.appendChild(temp3);
    }
  }
  size+=2;

  if(level==1)
    s=90;
  else if(level==2)
    s=80;
  shuffle(); 
}