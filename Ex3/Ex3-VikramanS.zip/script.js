function fun_onfocus(x){
  x.style.backgroundColor="lightblue";
}

function fun_onblur(x){
  x.style.backgroundColor="";
}

function fun_oninvalid(x){
  alert("Enter "+x.id);
}

function fun_onselect(x){
  alert('You have selected some text...!');
}

function fun_onkeypress(x){
  x.style.backgroundColor="lightblue";
}

function fun_onchange(x){
  var x = document.getElementById("marital_status").value;
  alert('You have selected '+x);
}
  
function validate(){
  var pattern1=/[a-zA-z]{1,50}/;
  var pattern2=/[a-zA-z0-9]{1,120}/;
  var pattern3=/[0-9]{10}/;

  var name=document.getElementById("name").value;
  var address=document.getElementById("address").value;
  var num=document.getElementById("num").value;
  var flag=0;
  if(!pattern1.test(name))
  {
    alert("invalid name...!");
    flag=1;
  }
  if(!pattern2.test(address))
  {
    alert("invalid address...!");
    flag=1;
  }
  if(!pattern3.test(num))
  {
    alert("invalid mobile number...!");
    flag=1
  }
  if(flag==1)
    return false;
  else
    return true;
}

function allowDrop(x){
  x.preventDefault();
}
function drag(x){
  x.dataTransfer.setData("text", x.target.id);
}
function drop(x){
  x.preventDefault();
  var data = x.dataTransfer.getData("text");
  x.target.appendChild(document.getElementById(data));
}

function fun_reset(){
  document.getElementById("box").innerHTML="";
  document.getElementById("address").innerHTML="";
  document.getElementById("list").innerHTML='<ul id="list"><li id="drag1" draggable="true" ondragstart="drag(event)"> Heroine </li><br><li id="drag2" draggable="true" ondragstart="drag(event)"> Cocaine </li><br><li id="drag3" draggable="true" ondragstart="drag(event)"> Crack </li><br><li id="drag4" draggable="true" ondragstart="drag(event)"> Hallucinogens </li><br><li id="drag5" draggable="true" ondragstart="drag(event)"> Amphetamines </li><br><li id="drag6" draggable="true" ondragstart="drag(event)"> Marijuana </li><br><li id="drag7" draggable="true" ondragstart="drag(event)"> Alcohol </li><br><li id="drag8" draggable="true" ondragstart="drag(event)"> Inhalants </li><br><li id="drag9" draggable="true" ondragstart="drag(event)"> Prescription Drugs </li><br> </ul>'
  alert('Form is resetted...!');
}

function startTime(){
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();     
  var s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById("time").innerHTML = h + ":" + m + ":" + s;  
  var t = setTimeout(startTime, 500); 
} 

function checkTime(i){
  if (i < 10) {i = "0" + i};
  return i;
} 

function fun_table(){
  if(validate())
  {
    var name=document.getElementById("name").value;
    var address=document.getElementById("address").value;
    var age=parseInt(document.getElementById("age").value);
    var dob=document.getElementById("dob").value;
    var gender= document.querySelector('input[name="gender"]:checked').value;
    var marital_status=document.getElementById("marital_status").value;
    var num=document.getElementById("num").value;
    var addiction=document.getElementById("box").innerHTML;
    
    document.writeln("<link rel=\"stylesheet\" href=\"style.css\">");
    document.writeln("<body>");
    document.writeln("<center><h1>Details</h1></center>");
    document.writeln("<table>");
    document.writeln("<tr><th>Details</td><th>Value</th></tr>");
    document.writeln("<tr><td>Name</td><td>"+name+"</td></tr>");
    document.writeln("<tr><td>Address</td><td>"+address+"</td></tr>");
    document.writeln("<tr><td>Age</td><td>"+age+"</td></tr>");
    document.writeln("<tr><td>Dob</td><td>"+dob+"</td></tr>");
    document.writeln("<tr><td>Gender</td><td>"+gender+"</td></tr>");    
    document.writeln("<tr><td>Marital Status</td><td>"+marital_status+"</td></tr>");
    document.writeln("<tr><td>Contact</td><td>"+num+"</td></tr>");
    document.writeln("<tr><td>Addiction</td><td>"+addiction+"</td></tr>");
    document.writeln("</table>");
  }
}